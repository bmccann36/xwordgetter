

import path from 'path';
import { Remarkable, ItemResponse } from 'remarkable-typescript';
// const { Remarkable, ItemResponse } = require('remarkable-typescript');
const fs = require('fs');

(async () => {
  /*
  * Create the reMarkable client
  * Params: { deviceToken?: string }
  * Returns: client: Remarkable
  */


  /*
  * Register your reMarkable and generate a device token. You must do this first to pair your device if you didn't specify a token. This may take a few seconds to complete. It seems that the deviceToken never expires.
  * Params: { code: string }
  * Returns: deviceToken: string
  */
  // const deviceToken = await client.register({ code: 'xgerimgk' });

  // (optional) skip registration in the future with `new Remarkable({deviceToken})`
  // console.log(deviceToken);
  const deviceToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdXRoMC11c2VyaWQiOiJhdXRoMHw1ZjJkOWVhYmMxM2JkODAwMzdjNWM3YmYiLCJkZXZpY2UtZGVzYyI6ImRlc2t0b3Atd2luZG93cyIsImRldmljZS1pZCI6IjM5MGY5ZGNmLThjNmQtNTAyMS1iYThkLWY2NDM3YTQwNDg5OCIsImlhdCI6MTYzMTM3MzYyNCwiaXNzIjoick0gV2ViQXBwIiwianRpIjoiY2swdC84V3IxZEU9IiwibmJmIjoxNjMxMzczNjI0LCJzdWIiOiJyTSBEZXZpY2UgVG9rZW4ifQ.r6BGqXcr2dD9I4NHr44lRkoEDWb5S879D76D2Bqv8Po'

  /*
* (Re)generate a token from the deviceToken. You MUST call this function after creating the client. This token, used to interact with storage, is different from the deviceToken. This function is automatically called in register(). This token expires.
* Params: none
* Returns: token: string
*/
  const client = new Remarkable({ deviceToken });
  await client.refreshToken();

  /*
    * Create a directory
    * Params: name: string, id: string, epubFileBuffer: Buffer, parent?: string
    * Returns: id: string
    */
  const directoryId = await client.createDirectory('testDir2', '702ba145-0a78-4e19-9324-6f8fb3da3c1a');

  console.log('directoryId :>> ', directoryId);


  /*
  * Upload a PDF to your reMarkable
  * Params: name: string, file: Buffer
  * Returns: id: string
  */



})();